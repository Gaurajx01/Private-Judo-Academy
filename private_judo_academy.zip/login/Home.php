<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sevenfightersfoundation</title>
    <link rel="shortcut icon" href="C:\Users\Asus\Downloads\gym-website-master\gym-website-master\images\sfc logo.png"  >

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
    
<!-- header section starts      -->

<header class="header">
    

    <a href="#" class="logo"> <span>Seven Fighters</span> club </a>

    <div id="menu-btn" class="fas fa-bars"></div>

    <nav class="navbar">
        <a href="Home.php">home</a>
        <a href="#about">about</a>
        <a href="#features">features</a>
        <a href="#trainers">training</a>
        <a href="#blogs">Events</a>
        <a href="#pricing">pricing</a>
        <a href="login.php">login</a>
        
    </nav>

</header>

<!-- header section ends     -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="swiper home-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide slide" style="background: url(images/home-bg-1.jpg) no-repeat;">
                <div class="content">
                    <span>Make yourself stronger than your excuses</span>
                    <h3>Maximum Efficiency Minimum Effort</h3>
                    <a href="register.php" class="btn">Register now</a>
                </div>
            </div>

            <div class="swiper-slide slide" style="background: url(images/home-bg-2.jpg) no-repeat;">
                <div class="content">
                    <span>be strong, be fit</span>
                    <h3>Make yourself stronger than your excuses.</h3>
                    <a href="register.php" class="btn">Register now</a>
                </div>
            </div>

            <div class="swiper-slide slide" style="background: url(images/home-bg-3.jpg) no-repeat;">
                <div class="content">
                    <span>be strong, be fit</span>
                    <h3>Make yourself stronger than your excuses.</h3>
                    <a href="register.php" class="btn">Register now</a>
                </div>
            </div>

        </div>

        <div class="swiper-pagination"></div>

    </div>

</section>

<!-- home section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <div class="image">
        <img src="images/logo.jpeg" alt="">
    </div>

    <div class="content">
        <span>about us</span>
        <h3 class="title">SEVEN FIGHTERS CLUB</h3>
        <p>This is a website based on private judo academy Seven Fighters Club this website will provide all the necessary information about academy. The main aim of Seven Fighters Foundation is to spread judo world wide and to win olymics medals for nation. Raising awareness of skill and rentleless dedication among judokas celebrating their achievements and supporting players on their sporting journey lie at the core of foundation we strive to achieve.</p>

        <div class="box-container">
            <div class="box">
                <h3><i class="fas fa-check"></i>Trains your mind</h3>
                <p>In judo you don’t just learn how to defend yourself better but also learn to control and trust your body as well.</p>
            </div>
            <div class="box">
                <h3><i class="fas fa-check"></i>Healthy life</h3>
                <p>Improved cardiovascular fitness and endurance. Make muscles and bones though.</p>
      </div>
            <div class="box">
                <h3><i class="fas fa-check"></i>Teaches Basic morals for life</h3>
                <p>Courtesy, courage, honesty, honour, modesty, respect, self-control and friendship are moral code we learn from judo.</p>
            </div>
            <div class="box">
                <h3><i class="fas fa-check"></i>Stress management</h3>
                <p>Relaxation and meditation throughout traning helps manage stress in daily life.</p>
            </div>
        </div>
        <a href="album.html" class="btn">about us</a>
    </div>

</section>

<!-- about section ends -->

<!-- features section starts  -->

<section class="features" id="features">

    <h1 class="heading"> <span>Judo features</span> </h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="images/f-img-1.jpg" alt="">
            </div>
            <div class="content">
                <img src="images/aglogo.png" alt="">
                <h3>Agility training</h3>
                <p>Agility training improves flexibility, balance, and control of body.</p>
                <a href="agility.html" class="btn">read more</a>
            </div>
        </div>

        <div class="box second">
            <div class="image">
                <img src="images/f-img-2.jpg" alt="">
            </div>
            <div class="content">
                <img src="images/icon-2.png" alt="">
                <h3>Power training</h3>
                <p>Typically involves exercises which apply the maximum amount of force as fast as possible.</p>
                <a href="power.html" class="btn">read more</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="images/f-img-3.jpg" alt="">
            </div>
            <div class="content">
                <img src="images/clogo.png" alt="">
                <h3>Circuit training</h3>
                <p>This workout gets your heart rate up and strengthens your muscles at the same time.</p>
                <a href="circuit.html" class="btn">read more</a>
            </div>
        </div>

    </div>

</section>
<!-- trainers section starts  -->

<section class="trainers" id="trainers">

    <h1 class="heading"> <span>Training sessions</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="images/ag2.jpg" alt="">
            <div class="content">
                <span></span>
                <h3></h3>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-pinterest"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>
        </div>

        <div class="box">
            <img src="images/pw2.jpg" alt="">
            <div class="content">
                <span></span>
                <h3></h3>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-pinterest"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>
        </div>

        <div class="box">
            <img src="images/pw3.jpg" alt="">
            <div class="content">
                <span></span>
                <h3></h3>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-pinterest"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>
        </div>

        <div class="box">
            <img src="images/ag1.jpg" alt="">
            <div class="content">
                <span></span>
                <h3></h3>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-pinterest"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>
        </div>
        
    </div>

</section>

<!-- trainers section ends -->

<!-- features section ends -->
<!-- blogs section starts  -->





<!-- blogs section ends -->

<!-- footer section starts  -->
<section class="blogs" id="blogs">

    <h1 class="heading"> <span>Events</span> </h1>

    <div class="swiper blogs-slider">

        <div class="swiper-wrapper">
        <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/ec1.jpg" alt="">
                </div>
                <div class="content">
                    <div class="link"> <a href="#">Event date</a> <span>|</span> <a href="#">coming soon</a> </div>
                    <h3>Summer camps</h3>
                    <p>This year summer camps are coming with more suprises </p>
                    <a href="camp.html" class="btn">read more</a>
                </div>
            </div>


            <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/em.jpg" alt="">
                </div>
                <div class="content">
                    <div class="link"> <a href="#">Event date</a> <span>|</span> <a href="#">28th Jan, 2022</a> </div>
                    <h3>Monthly Activity</h3>
                    <p> View every month activity highlights  </p>
                    <a href="monthly activity.html" class="btn">read more</a>
                </div>
            </div>
            
            
            <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/ryp.jpg" alt="">
                </div>
                <div class="content">
                    <div class="link"> <a href="#">Event date</a> <span>|</span> <a href="#">21st may, 2021</a> </div>
                    <h3>RYP Championship</h3>
                    <p>Results</p>
                    <a href="rypchamp.html" class="btn">read more</a>
                </div>
            </div>

            <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/nj0.jpg" alt="">
                </div>
                <div class="content">
                    <div class="link"> <a href="#">by user</a> <span>|</span> <a href="#">21st may, 2021</a> </div>
                    <h3> 48th Sub-Junior National Judo Championship</h3>
                    <p>Results</p>
                    <a href="national.html" class="btn">read more</a>
                </div>
            </div>

            <div class="swiper-slide slide">
                <div class="image">
                    <img src="images/st5.jpg" alt="">
                </div>
                <div class="content">
                    <div class="link"> <a href="#">by user</a> <span>|</span> <a href="#">21st may, 2021</a> </div>
                    <h3> 48th Sub-Junior State Judo Championship</h3>
                    <p>Results</p>
                    <a href="state.html" class="btn">read more</a>
                </div>
            </div>

        </div>

        <div class="swiper-pagination"></div>

    </div>

</section>


<!-- pricing section starts  -->

<section class="pricing" id="pricing">

    <div class="information">
        <span>pricing plan</span>
        <h3>affordable pricing plan for your</h3>
        <p> Get progressive trainings programs with judo and selfdefense as per your convienece and requirement </p>
        <p> <i class="fas fa-check"></i> Power training </p>
        <p> <i class="fas fa-check"></i> Agility traning </p>
        <p> <i class="fas fa-check"></i> Circuit taining</p>
        <p> <i class="fas fa-check"></i> Diet plans </p>
        <p> <i class="fas fa-check"></i> overall results </p>
        
    </div>

    <div class="plan basic">
        <h3>basic plan</h3>
        <div class="price"><span>₹</span>600<span>/mo</span></div>
       <div class="list">
       
       <p> <i class="fas fa-check"></i> Judo traning </p>
        <p> <i class="fas fa-check"></i> Aikido traning</p>
        <p> <i class="fas fa-check"></i> Ciruit traning </p>
        <p> <i class="fas fa-check"></i> power training</p>
        <p> <i class="fas fa-check"></i> overall results </p>

       </div>
       <a href="payment.html" class="btn">get started</a>

    </div>

    <div class="plan">
        <h3>premium plan</h3>
        <div class="price"><span>₹</span>900<span>/mo</span></div>
       <div class="list">
        <p> <i class="fas fa-check"></i> personal training </p>
        <p> <i class="fas fa-check"></i> judo training </p>
        <p> <i class="fas fa-check"></i> Aikido traning </p>
        <p> <i class="fas fa-check"></i> circuit traning </p>
        <p> <i class="fas fa-check"></i> power training </p>

        <p> <i class="fas fa-check"></i> diet plans </p>
        <p> <i class="fas fa-check"></i> overall results </p>
       </div>
       <a href="payment.html" class="btn">get started</a>
       
    </div>

</section>

<!-- pricing section ends -->



<!-- banner section starts  -->

<section class="banner">

    <span>join us now</span>
    <h3>get upto 30% discount Premium Plan</h3>
    <p>Special offer for new year joining.</p>
   

</section>

<!-- banner section ends -->

<!-- review section starts  -->


<!-- review section ends -->


<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a class="links" href="#home">home</a>
            <a class="links" href="#about">about</a>
            <a class="links" href="#features">features</a>
            <a class="links" href="#pricing">pricing</a>
            <a class="links" href="#trainers">trainers</a>
            <a class="links" href="#blogs">blogs</a>
            <a class="links" href="login.php">login</a>
        </div>

        <div class="box">
            <h3>opening hours</h3>
            <p> monday : <i> 7:00am - 10:30pm </i> </p>
            <p> tuesday : <i> 7:00am - 10:30pm </i> </p>
            <p> wednesday : <i> 7:00am - 10:30pm </i> </p>
            <p> friday : <i> 7:00am - 10:30pm </i> </p>
            <p> saturday : <i> 7:00am - 10:30pm </i> </p>
            <p> sunday : <i> closed </i> </p>
        </div>

        <div class="box">
            <h3>Contact us</h3>
            <p> <i class="fas fa-phone"></i> +123-456-7890 </p>
            <p> <i class="fas fa-phone"></i> +111-222-3333 </p>
            <p> <i class="fas fa-envelope" ></i> sevenfighter7@gmail.com </p>
            <p> <i class="fas fa-map"></i> Dombivli, india - 401204 </p>
            <div class="share">
                <a href="https://www.facebook.com/sevenfightersclub/?ti=as" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/seven_fighters_club/" class="fab fa-linkedin"></a>
                <a href="#" class="fab fa-pinterest"></a>
            </div>
        </div>

        

    </div>

</section>

<div class="credit">Thankyou for visiting </div>

<!-- footer section ends -->













<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>