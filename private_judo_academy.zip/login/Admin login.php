<?php require("connection.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Panel</title>
</head>
<body>
<div class="container">
<div class="myform">
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>">
    <h2>ADMIN LOGIN</h2>
    <input type="text"  placeholder="Admin_name" name="Admin_Name">
    <input type="password"  placeholder="Password" name="Admin_Password">
  
  <button type="submit" name="Login">LOGIN</button>
</form>
</div>

<?php 
    error_reporting(0);
    function input_filter($data)
    {
        $data=trim($data);
        $data=stripslashes($data);
        $data=htmlspecialchars($data);
        return $data;


    }
  
  if(isset($_POST['Login'])){
     $AdminName=input_filter($_POST['Admin_Name']);
     $AdminPass=input_filter($_POST['Admin_Password']);

     $AdminName=mysqli_real_escape_string($con,$Admin_Name);
     $AdminPass=mysqli_real_escape_string($con,$Admin_Password);

     $query="SELECT * FROM `Admin_login`  WHERE 'Admin_Name'=? AND 'Admin_Password'=?";

     if($stmt=mysqli_prepare($con,$query))
     {
      mysqli_stmt_bind_param($stmt,"ss",$Admin_Name,$Admin_Password);
      mysqli_stmt_execute($stmt);
      mysqli_stmt_store_result($stmt);
      if(mysqli_stmt_num_rows($stmt)==1)
      {
          echo"details matched";
      }
      else {
          echo"<script>alert('Invaid Admin Name or Password');</script>";
      }
     }
     else 
     {
          echo"<script>alert('SQL Query cannot be prepared');</script>";
           
     }

     
       

  }

?>



</body>
</html>