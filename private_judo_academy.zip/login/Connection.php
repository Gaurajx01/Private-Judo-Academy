<?php

$con=mysqli_connect("localhost","root","","admin");

if(mysqli_connect_error()){
    echo"cannot connect to database";
    exit();
}



?>